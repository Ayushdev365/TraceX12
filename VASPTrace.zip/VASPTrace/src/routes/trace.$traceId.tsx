import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Glass, StatCard } from "@/components/ui/glass";
import { TraceGraph } from "@/components/trace-graph";
import { getSahyogDraft, getTrace, reviewTrace, summarizeTrace } from "@/lib/server/functions";
import type { GraphNode, TraceResult } from "@/lib/trace/types";
import { explorerUrl, formatUnix, shortenAddress, txExplorerUrl } from "@/lib/utils";

export const Route = createFileRoute("/trace/$traceId")({ component: TracePage });

function bandLabel(band: TraceResult["confidenceBand"]) {
  if (band === "high") return "High (heuristic)";
  if (band === "moderate") return "Moderate (heuristic)";
  if (band === "low") return "Low (heuristic)";
  if (band === "insufficient") return "Insufficient evidence";
  return "No attribution";
}

function ScoreRing({ score }: { score: number }) {
  const r = 16;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, score)) / 100) * c;
  return (
    <svg viewBox="0 0 40 40" className="score-ring size-10 shrink-0" aria-hidden="true">
      <circle cx="20" cy="20" r={r} className="text-white/10" stroke="currentColor" />
      <circle
        cx="20"
        cy="20"
        r={r}
        className="text-accent"
        stroke="currentColor"
        strokeDasharray={c}
        strokeDashoffset={offset}
      />
    </svg>
  );
}

function TracePage() {
  const { traceId } = Route.useParams();
  const [result, setResult] = useState<TraceResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<GraphNode | null>(null);
  const [brief, setBrief] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    getTrace({ data: { id: traceId } })
      .then((row) => {
        if (!live) return;
        if (!row) setError("Trace not found.");
        else setResult(row);
      })
      .catch((err: unknown) => setError(err instanceof Error ? err.message : "Failed to load trace."));
    return () => {
      live = false;
    };
  }, [traceId]);

  const jsonHref = useMemo(() => {
    if (!result) return null;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
    return URL.createObjectURL(blob);
  }, [result]);

  async function decide(decision: TraceResult["reviewDecision"]) {
    setBusy("review");
    try {
      const next = await reviewTrace({ data: { id: traceId, decision } });
      if (next) setResult(next);
    } finally {
      setBusy(null);
    }
  }

  async function briefing() {
    setBusy("brief");
    try {
      const out = await summarizeTrace({ data: { id: traceId } });
      if (out.ok) setBrief(out.text);
      else setBrief(out.error);
    } finally {
      setBusy(null);
    }
  }

  async function downloadDraft() {
    setBusy("draft");
    try {
      const out = await getSahyogDraft({ data: { id: traceId } });
      if ("error" in out) {
        setBrief(out.error ?? "Could not generate the disclosure draft.");
        return;
      }
      const blob = new Blob([JSON.stringify(out.draft, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `sahyog-mock-${traceId.slice(0, 8)}.json`;
      a.click();
    } finally {
      setBusy(null);
    }
  }

  if (error) {
    return (
      <AppShell>
        <p className="text-danger">{error}</p>
      </AppShell>
    );
  }
  if (!result) {
    return (
      <AppShell>
        <p className="text-muted">Loading trace…</p>
      </AppShell>
    );
  }

  const attr = result.attributed;

  return (
    <AppShell wide>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="kicker">Trace {result.traceId.slice(0, 8)}</p>
          <h1 className="mt-2 font-mono text-lg tracking-tight text-fg sm:text-xl">{result.wallet}</h1>
          <p className="mt-1 text-sm text-muted">
            {result.chain === "ethereum" ? "Ethereum" : "Tron"} · {result.hopCap}-hop cap · {result.txsAnalyzed}{" "}
            transfers · {result.addressesVisited} addresses · {result.elapsedMs} ms · {result.dataSource}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/report/$traceId" params={{ traceId }} className="glass-btn">
            Open report
          </Link>
          {jsonHref ? (
            <a href={jsonHref} download={`vasptrace-${traceId.slice(0, 8)}.json`} className="glass-btn">
              Download JSON
            </a>
          ) : null}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Attributed VASP" value={attr ? attr.vaspName : "No reliable VASP attribution found"} />
        <StatCard
          label="Heuristic score"
          value={attr ? `${attr.score}/100` : "—"}
          hint={bandLabel(result.confidenceBand)}
          trailing={attr ? <ScoreRing score={attr.score} /> : null}
        />
        <StatCard label="Hop distance" value={attr ? String(attr.hopDistance) : "—"} />
        <StatCard label="Review" value={result.reviewDecision} />
      </div>

      {result.completeness !== "full" ? (
        <p className="chip chip-warn mt-4 min-h-10 w-full justify-start rounded-xl px-3 py-2 text-sm tracking-normal">
          {result.completeness === "empty" ? "No transfers retrieved. " : "Partial data. "}
          {result.completenessNote}
        </p>
      ) : null}

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,0.9fr)]">
        <div className="space-y-3">
          <h2 className="text-sm font-semibold">Transaction path</h2>
          <TraceGraph result={result} onSelect={setSelected} />
          <p className="text-xs text-subtle">Click a node for address, label, source and hop distance.</p>
        </div>

        <div className="space-y-3">
          <Glass lite className="rounded-3xl p-5">
            <h2 className="label-caps">Why this attribution?</h2>
            {attr ? (
              <ul className="mt-3 space-y-2 text-sm leading-relaxed text-muted">
                {attr.why.map((line) => (
                  <li key={line}>{line}</li>
                ))}
              </ul>
            ) : (
              <p className="mt-3 text-sm leading-relaxed text-muted">
                No labelled VASP was reached with enough evidence inside the hop cap. This is reported as inconclusive
                rather than forced.
              </p>
            )}
            <p className="mt-4 text-xs leading-relaxed text-subtle">{result.heuristicDisclaimer}</p>
          </Glass>

          {attr ? (
            <Glass lite className="rounded-3xl p-5">
              <h3 className="text-sm font-semibold">Score breakdown</h3>
              <ul className="mt-3 space-y-2 text-sm">
                {Object.entries(attr.breakdown).map(([k, v]) => (
                  <li key={k} className="flex items-start justify-between gap-3">
                    <span className="text-muted">
                      {k.replace(/[A-Z]/g, (m) => " " + m.toLowerCase())}
                      <span className="mt-0.5 block text-xs text-subtle">{v.note}</span>
                    </span>
                    <span className="font-mono tabular-nums text-fg">
                      {v.awarded}/{v.max || "—"}
                    </span>
                  </li>
                ))}
              </ul>
            </Glass>
          ) : null}

          {result.riskFlags.length ? (
            <Glass lite className="rounded-3xl p-5">
              <h3 className="text-sm font-semibold">Risk flags</h3>
              <ul className="mt-3 space-y-3">
                {result.riskFlags.map((f) => (
                  <li key={f.title + (f.address ?? "")}>
                    <p className="text-sm text-fg">
                      {f.title} <span className="chip chip-danger ml-1">{f.kind}</span>
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-muted">{f.detail}</p>
                  </li>
                ))}
              </ul>
            </Glass>
          ) : (
            <p className="text-sm text-muted">No mixer, bridge, or high-fan-out flags on the retrieved path.</p>
          )}
        </div>
      </div>

      {selected ? (
        <Glass lite className="mt-6 rounded-3xl p-5">
          <h3 className="text-sm font-semibold">Selected node</h3>
          <dl className="mt-3 grid gap-3 text-sm sm:grid-cols-2">
            <Field label="Address" value={selected.address} mono />
            <Field label="Chain" value={result.chain} />
            <Field label="Label" value={selected.label ?? "Unlabelled"} />
            <Field label="Hop" value={String(selected.hop)} />
            <Field label="Role" value={selected.role} />
            <Field label="Transfers in window" value={String(selected.txCount)} />
            <Field label="Source" value={selected.source ?? "—"} />
            <Field label="Explorer" value="Open" href={explorerUrl(result.chain, selected.address)} />
          </dl>
        </Glass>
      ) : null}

      {attr?.sampleTxs.length ? (
        <div className="table-wrap mt-6">
          <div className="border-b border-white/8 px-4 py-3 text-sm font-semibold">Connecting transfers</div>
          <div className="overflow-x-auto">
            <table>
              <thead>
                <tr>
                  <th className="font-medium">From</th>
                  <th className="font-medium">To</th>
                  <th className="font-medium">Amount</th>
                  <th className="font-medium">Time</th>
                  <th className="font-medium">Tx</th>
                </tr>
              </thead>
              <tbody>
                {attr.sampleTxs.map((e) => (
                  <tr key={e.id}>
                    <td className="font-mono text-xs">{shortenAddress(e.from)}</td>
                    <td className="font-mono text-xs">{shortenAddress(e.to)}</td>
                    <td>{e.amountDisplay}</td>
                    <td className="text-muted">{formatUnix(e.timestamp)}</td>
                    <td>
                      <a
                        className="text-accent hover:underline"
                        href={txExplorerUrl(result.chain, e.txHash)}
                        target="_blank"
                        rel="noreferrer"
                      >
                        explorer
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      <Glass live className="mt-6 rounded-3xl p-5">
        <h3 className="text-sm font-semibold">Human review</h3>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          Accepting a lead unlocks the mock SAHYOG disclosure draft. Rejecting it records that the investigator did not
          rely on this attribution. Nothing is submitted to any government API.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button disabled={busy === "review"} onClick={() => void decide("accepted")}>
            Accept lead
          </Button>
          <Button variant="secondary" disabled={busy === "review"} onClick={() => void decide("rejected")}>
            Reject
          </Button>
          <Button variant="ghost" disabled={busy === "review"} onClick={() => void decide("inconclusive")}>
            Mark inconclusive
          </Button>
          <Button
            variant="secondary"
            disabled={result.reviewDecision !== "accepted" || busy === "draft"}
            onClick={() => void downloadDraft()}
          >
            Mock SAHYOG draft
          </Button>
          <Button variant="ghost" disabled={busy === "brief"} onClick={() => void briefing()}>
            Plain-language briefing
          </Button>
        </div>
        {brief ? <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-muted">{brief}</p> : null}
      </Glass>
    </AppShell>
  );
}

function Field({
  label,
  value,
  mono,
  href,
}: {
  label: string;
  value: string;
  mono?: boolean;
  href?: string;
}) {
  return (
    <div>
      <p className="label-caps">{label}</p>
      {href ? (
        <a href={href} target="_blank" rel="noreferrer" className="mt-1 inline-block text-accent hover:underline">
          {value}
        </a>
      ) : (
        <p className={`mt-1 break-all ${mono ? "font-mono text-xs" : ""}`}>{value}</p>
      )}
    </div>
  );
}
