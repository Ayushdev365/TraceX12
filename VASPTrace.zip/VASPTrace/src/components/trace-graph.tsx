import { useEffect, useMemo, useState } from "react";
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  type Edge,
  type Node,
  type NodeMouseHandler,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import type { GraphEdge, GraphNode, TraceResult } from "@/lib/trace/types";
import { shortenAddress } from "@/lib/utils";

const ROLE_COLOR: Record<GraphNode["role"], { bg: string; border: string; fg: string }> = {
  unknown_wallet: { bg: "#1c2028", border: "#f3f5f8", fg: "#f3f5f8" },
  intermediate: { bg: "#12151b", border: "#4a5260", fg: "#9aa3b0" },
  vasp: { bg: "#12332f", border: "#8fd0c8", fg: "#8fd0c8" },
  risk: { bg: "#2a1515", border: "#d07070", fg: "#d07070" },
  both: { bg: "#2a2415", border: "#d0b06a", fg: "#d0b06a" },
};

function layout(nodes: GraphNode[], edges: GraphEdge[]): { flowNodes: Node[]; flowEdges: Edge[] } {
  const byHop = new Map<number, GraphNode[]>();
  for (const n of nodes) {
    const list = byHop.get(n.hop) ?? [];
    list.push(n);
    byHop.set(n.hop, list);
  }
  const flowNodes: Node[] = [];
  for (const [hop, list] of byHop) {
    list.forEach((n, i) => {
      const colors = ROLE_COLOR[n.role];
      flowNodes.push({
        id: n.addressNorm,
        position: { x: hop * 240, y: i * 110 },
        data: {
          label: n.label ? `${n.label}` : shortenAddress(n.address, 8, 6),
          sub: n.vaspName ?? (n.role === "unknown_wallet" ? "Investigated wallet" : `hop ${n.hop}`),
        },
        style: {
          background: colors.bg,
          border: `1px solid ${colors.border}`,
          color: colors.fg,
          borderRadius: 14,
          fontSize: 12,
          width: 180,
          padding: 10,
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.12)",
        },
      });
    });
  }
  const flowEdges: Edge[] = edges.map((e) => ({
    id: e.id,
    source: e.fromNorm,
    target: e.toNorm,
    animated: false,
    label: e.amountDisplay,
    style: { stroke: "#4a5260" },
    labelStyle: { fill: "#9aa3b0", fontSize: 10 },
  }));
  return { flowNodes, flowEdges };
}

export function TraceGraph({
  result,
  onSelect,
}: {
  result: TraceResult;
  onSelect: (node: GraphNode | null) => void;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const { flowNodes, flowEdges } = useMemo(
    () => layout(result.nodes, result.edges),
    [result.nodes, result.edges],
  );

  const onNodeClick: NodeMouseHandler = (_, node) => {
    const found = result.nodes.find((n) => n.addressNorm === node.id) ?? null;
    onSelect(found);
  };

  if (!mounted) {
    return (
      <div className="glass-lite flex h-[420px] items-center justify-center rounded-3xl text-sm text-muted">
        Loading path graph…
      </div>
    );
  }

  if (result.nodes.length === 0) {
    return (
      <div className="glass-lite flex h-[320px] items-center justify-center rounded-3xl text-sm text-muted">
        No graph to display.
      </div>
    );
  }

  return (
    <div className="glass-lite h-[min(520px,70dvh)] overflow-hidden rounded-3xl">
      <ReactFlow
        nodes={flowNodes.map((n) => ({
          ...n,
          data: {
            label: (
              <div className="text-left">
                <div className="font-mono text-xs leading-tight">{String((n.data as { label: string }).label)}</div>
                <div className="mt-1 text-2xs text-muted">{String((n.data as { sub: string }).sub)}</div>
              </div>
            ),
          },
        }))}
        edges={flowEdges}
        fitView
        minZoom={0.3}
        maxZoom={1.6}
        onNodeClick={onNodeClick}
        proOptions={{ hideAttribution: true }}
      >
        <Background gap={20} color="rgba(255,255,255,0.05)" />
        <MiniMap
          pannable
          zoomable
          maskColor="rgba(7,8,12,0.72)"
          nodeColor={(n) => String(n.style?.border ?? "#4a5260")}
        />
        <Controls showInteractive={false} />
      </ReactFlow>
    </div>
  );
}
